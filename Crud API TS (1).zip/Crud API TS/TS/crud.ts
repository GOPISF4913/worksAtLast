interface Contact {
  id: any;
  name: string;
  email: string;
  phone: string;
  dob: string;
  languages: string[];
  balance: number;
  photo: string[];
}

let editingId: number = 0;
const form = document.getElementById("form") as HTMLFormElement;// form element
const nameInput = document.getElementById("name") as HTMLInputElement;
const emailInput = document.getElementById("email") as HTMLInputElement;
const phoneInput = document.getElementById("phone") as HTMLInputElement;
const dobInput = document.getElementById("date") as HTMLInputElement;
const balanceInput = document.getElementById("balance") as HTMLInputElement;
const photoInput = document.getElementById("fileInput") as HTMLInputElement;
const selectElement = document.getElementById("multiSelect") as HTMLSelectElement;

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const name = nameInput.value.trim();
  const email = emailInput.value.trim();
  const phone = phoneInput.value.trim();
  const dob = dobInput.value.trim();
  const balance = parseFloat(balanceInput.value.trim());
  const selectedOptions = Array.from(selectElement.selectedOptions).map(option => option.value);
  const file = photoInput.files?.[0];
  const reader = new FileReader();

  reader.onload = function (event) {
    const base64String = event.target?.result as string;

    if (editingId !== 0) {
      const contact: Contact = {
        id: editingId,
        name: name,
        email: email,
        phone: phone,
        dob: dob,
        languages: selectedOptions,
        balance: balance,
        photo: [base64String]
      };
      updateContact(editingId, contact);
    }
    else {
      const contact: Contact = {
        id: undefined, // Only Undefined will be auto incremented in DB
        name: name,
        email: email,
        phone: phone,
        dob: dob,
        languages: selectedOptions,
        balance: balance,
        photo: [base64String]
      };
      addContact(contact);
    }
  };
  if (file) {
    reader.readAsDataURL(file); // Read the file as a data URL (Base64 encoded)
  }
  form.reset();
});

document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('contactForm') as HTMLFormElement;
  renderContacts();
});

function addnewContact() {
  editingId = 0;
  form.reset();
}
async function exportToCSV() {
  const exportData = await fetchContacts();
  var output = "";
  exportData.forEach(element => {
    output += element.name + "," + element.email + "," + element.phone + "," + element.dob + "," + element.languages.join("-") + "," + element.balance + "\n";
  });

  const blob = new Blob([output], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', 'contacts.csv');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

async function fetchContacts(): Promise<Contact[]> {
  const apiUrl = 'http://localhost:5170/api/contacts';
  const response = await fetch(apiUrl);
  if (!response.ok) {
    throw new Error('Failed to fetch contacts');
  }
  return await response.json();
}

async function renderContacts() {
  try {
    const tableBody = document.getElementById('contactTableBody') as HTMLTableSectionElement;
    const contacts = await fetchContacts();
    tableBody.innerHTML = '';
    contacts.forEach(contact => {
      const row = document.createElement('tr');
      row.innerHTML = `
          <td>${contact.name}</td>
          <td>${contact.email}</td>
          <td>${contact.phone}</td>
          <td>${contact.dob.split('T')[0].split('-').reverse().join('/')}</td>
          <td>${contact.languages.join(', ')}</td>
          <td>${contact.balance}</td>
          <td><img src="${contact.photo[0]}" style="width: 100px; height: auto;" alt="Photo"></td>
          <td>
            <button onclick="editContact('${contact.id}')">Edit</button>
            <button onclick="deleteContact('${contact.id}')">Delete</button>
          </td>
        `;
      tableBody.appendChild(row);
    });
  } catch (error) {
    console.error('Error fetching contacts:', error);
  }
}

async function editContact(id: string) {
  editingId = parseInt(id);
  const contacts = await fetchContacts();
  const contact = contacts.find(contact => contact.id === editingId);
  if (contact) {
    nameInput.value = contact.name;
    emailInput.value = contact.email;
    phoneInput.value = contact.phone;
    const dobDate = new Date(contact.dob);
    const formattedDOB = dobDate.toLocaleDateString("es-CL").split("-");
    const format = formattedDOB[2] + "-" + formattedDOB[1] + "-" + formattedDOB[0];
    dobInput.value = format;
    //Multiselect dropdown
    if (contact.languages.length > 0) {
      // Set the value of the select element to the first language in the array
      selectElement.value = contact.languages[0];

      // If there are multiple languages, you may want to select additional options or handle them differently
      for (let i = 1; i < contact.languages.length; i++) {
        // Assuming each language option has a unique value
        const languageOption = selectElement.querySelector(`option[value="${contact.languages[i]}"]`) as HTMLOptionElement | null;
        if (languageOption) {
          languageOption.selected = true;
        }
      }
    } else {
      // If no languages are specified, you may want to set a default option or handle it differently
      selectElement.value = ""; // or some default value
    }
    balanceInput.value = contact.balance.toString();
  }
}

async function addContact(contact: Contact): Promise<void> {
  const response = await fetch('http://localhost:5170/api/Contacts', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(contact)
  });
  if (!response.ok) {
    throw new Error('Failed to add contact');
  }
  renderContacts();
}

async function updateContact(id: number, contact: Contact): Promise<void> {
  const response = await fetch(`http://localhost:5170/api/Contacts/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(contact)
  });
  if (!response.ok) {
    throw new Error('Failed to update contact');
  }
  renderContacts();
}

async function deleteContact(id: number): Promise<void> {
  const response = await fetch(`http://localhost:5170/api/Contacts/${id}`, {
    method: 'DELETE'
  });
  if (!response.ok) {
    throw new Error('Failed to delete contact');
  }
  renderContacts();
}



